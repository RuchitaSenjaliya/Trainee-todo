import React from "react";
import Navbar from "../components/navbar/Navbar";

export default function ContactPage() {
  return (
    <>
      <div className="contact">
        <div className="home">
          <div className="content">
            <div className="title">Contact us</div>
          </div>
        </div>
      </div>
    </>
  );
}
